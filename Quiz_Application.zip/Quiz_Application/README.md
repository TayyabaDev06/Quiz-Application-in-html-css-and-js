# Quiz_Application
Quiz application in Html, Css, js
![Screenshot (153)](https://github.com/caspercruz/Quiz_Application/assets/85841843/30b24de9-c1ce-4730-a7b0-f149454cafa3)
![Screenshot (152)](https://github.com/caspercruz/Quiz_Application/assets/85841843/17208f1a-dbba-4cbc-8b42-b20fd142f43c)
